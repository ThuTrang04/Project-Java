package buoi11;

public class Person {
    protected String Hoten;
    protected int Tuoi;

    public Person(){}
    public Person(String Hoten, int Tuoi){
        this.Hoten = Hoten;
        this.Tuoi = Tuoi;
    }
}
